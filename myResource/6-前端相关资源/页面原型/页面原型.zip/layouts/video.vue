<template>
    <div>
        <div>视频播放器组件正在初始化，请稍后......</div>
        <nuxt />
    </div>
</template>

<script>
export default {
    
}
</script>

